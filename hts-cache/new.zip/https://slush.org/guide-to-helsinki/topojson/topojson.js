<!doctype html>
<html dir="ltr" lang="en-US"
	prefix="og: https://ogp.me/ns#"  class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" /><title>Page not found &#8211; Slush 2023</title>

		<!-- All in One SEO 4.3.2 - aioseo.com -->
		<meta name="robots" content="noindex" />
		<meta name="generator" content="All in One SEO (AIOSEO) 4.3.2 " />
		<script type="application/ld+json" class="aioseo-schema">
			{"@context":"https:\/\/schema.org","@graph":[{"@type":"BreadcrumbList","@id":"https:\/\/slush.org\/guide-to-helsinki\/topojson\/topojson.js#breadcrumblist","itemListElement":[{"@type":"ListItem","@id":"https:\/\/slush.org\/#listItem","position":1,"item":{"@type":"WebPage","@id":"https:\/\/slush.org\/","name":"Home","description":"Slush 2023 coming Nov 30\u2013Dec 1 to Helsinki. Slush gathers 5,000 founders, 3,000 investors, and the world's largest gathering of VC under one roof.","url":"https:\/\/slush.org\/"},"nextItem":"https:\/\/slush.org\/guide-to-helsinki\/topojson\/topojson.js#listItem"},{"@type":"ListItem","@id":"https:\/\/slush.org\/guide-to-helsinki\/topojson\/topojson.js#listItem","position":2,"item":{"@type":"WebPage","@id":"https:\/\/slush.org\/guide-to-helsinki\/topojson\/topojson.js","name":"Not Found","url":"https:\/\/slush.org\/guide-to-helsinki\/topojson\/topojson.js"},"previousItem":"https:\/\/slush.org\/#listItem"}]},{"@type":"Organization","@id":"https:\/\/slush.org\/#organization","name":"Slush","url":"https:\/\/slush.org\/","logo":{"@type":"ImageObject","url":"https:\/\/slush.org\/wp-content\/uploads\/2023\/05\/slush-s-icon.jpeg","@id":"https:\/\/slush.org\/#organizationLogo","width":192,"height":192,"caption":"Slush logo"},"image":{"@id":"https:\/\/slush.org\/#organizationLogo"}},{"@type":"WebPage","@id":"https:\/\/slush.org\/guide-to-helsinki\/topojson\/topojson.js#webpage","url":"https:\/\/slush.org\/guide-to-helsinki\/topojson\/topojson.js","inLanguage":"en-US","isPartOf":{"@id":"https:\/\/slush.org\/#website"},"breadcrumb":{"@id":"https:\/\/slush.org\/guide-to-helsinki\/topojson\/topojson.js#breadcrumblist"}},{"@type":"WebSite","@id":"https:\/\/slush.org\/#website","url":"https:\/\/slush.org\/","name":"Slush 2023","alternateName":"Slush","description":"The World's Leading Startup Event","inLanguage":"en-US","publisher":{"@id":"https:\/\/slush.org\/#organization"}}]}
		</script>
		<!-- All in One SEO -->

<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Slush 2023 &raquo; Feed" href="https://slush.org/feed/" />
<link rel="alternate" type="application/rss+xml" title="Slush 2023 &raquo; Comments Feed" href="https://slush.org/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/slush.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.3.1"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='formidable-css' href='https://slush.org/wp-content/plugins/formidable/css/formidableforms.css?ver=11101152' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css' href='https://slush.org/wp-includes/css/dist/block-library/style.min.css?ver=6.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='cp_timeline-cgb-style-css-css' href='https://slush.org/wp-content/plugins/cool-timeline/includes/cool-timeline-block/dist/blocks.style.build.css' type='text/css' media='all' />
<link rel='stylesheet' id='gctl-timeline-styles-css-css' href='https://slush.org/wp-content/plugins/timeline-block/includes/gutenberg-block/build/blocks.style.build.css?ver=6.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='cltb_cp_timeline-cgb-style-css-css' href='https://slush.org/wp-content/plugins/timeline-block/includes/cool-timeline-block/dist/blocks.style.build.css' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='uaf_client_css-css' href='https://slush.org/wp-content/uploads/useanyfont/uaf.css?ver=1680172518' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://slush.org/wp-content/themes/salient/css/font-awesome-legacy.min.css?ver=4.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='salient-grid-system-css' href='https://slush.org/wp-content/themes/salient/css/build/grid-system.css?ver=15.0.8' type='text/css' media='all' />
<link rel='stylesheet' id='main-styles-css' href='https://slush.org/wp-content/themes/salient/css/build/style.css?ver=15.0.8' type='text/css' media='all' />
<style id='main-styles-inline-css' type='text/css'>

		#error-404{
		  text-align:center;
		  padding: 10% 0;
		  position: relative;
		  z-index: 10;
		}
		body.error {
		  padding: 0;
		}
		body #error-404[data-cc="true"] h1,
		body #error-404[data-cc="true"] h2,
		body #error-404[data-cc="true"] p {
		  color: inherit;
		}
		body.error404 .error-404-bg-img,
		body.error404 .error-404-bg-img-overlay {
		  position: absolute;
		  top: 0;
		  left: 0;
		  width: 100%;
		  height: 100%;
		  background-size: cover;
		  background-position: 50%;
		  z-index: 1;
		}
		body.error404 .error-404-bg-img-overlay {
		  opacity: 0.8;
		}
		body #error-404 h1,
		body #error-404 h2 {
		  font-family: "Open Sans";
		  font-weight:700
		}
		body #ajax-content-wrap #error-404 h1 {
		  font-size:250px;
		  line-height:250px;
		}
		body #ajax-content-wrap #error-404 h2 {
		  font-size:54px;
		}
		body #error-404 .nectar-button {
		  margin-top: 50px;
		}

		@media only screen and (max-width : 690px) {

			body .row #error-404 h1,
			body #ajax-content-wrap #error-404 h1 {
				font-size: 150px;
				line-height: 150px;
			}

			body #ajax-content-wrap #error-404 h2 {
				font-size: 32px;
			}

			body .row #error-404 {
				margin-bottom: 0;
			}
		}
		
html:not(.page-trans-loaded) { background-color: #ffffff; }
</style>
<link rel='stylesheet' id='nectar-header-perma-transparent-css' href='https://slush.org/wp-content/themes/salient/css/build/header/header-perma-transparent.css?ver=15.0.8' type='text/css' media='all' />
<link rel='stylesheet' id='nectar_default_font_open_sans-css' href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-css' href='https://slush.org/wp-content/themes/salient/css/build/responsive.css?ver=15.0.8' type='text/css' media='all' />
<link rel='stylesheet' id='skin-material-css' href='https://slush.org/wp-content/themes/salient/css/build/skin-material.css?ver=15.0.8' type='text/css' media='all' />
<link rel='stylesheet' id='salient-wp-menu-dynamic-css' href='https://slush.org/wp-content/uploads/salient/menu-dynamic.css?ver=36756' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css' href='https://slush.org/wp-content/plugins/js_composer_salient/assets/css/js_composer.min.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='dynamic-css-css' href='https://slush.org/wp-content/themes/salient/css/salient-dynamic-styles.css?ver=47038' type='text/css' media='all' />
<style id='dynamic-css-inline-css' type='text/css'>
#header-space{background-color:#101010}@media only screen and (min-width:1000px){body #ajax-content-wrap.no-scroll{min-height:calc(100vh - 86px);height:calc(100vh - 86px)!important;}}@media only screen and (min-width:1000px){#page-header-wrap.fullscreen-header,#page-header-wrap.fullscreen-header #page-header-bg,html:not(.nectar-box-roll-loaded) .nectar-box-roll > #page-header-bg.fullscreen-header,.nectar_fullscreen_zoom_recent_projects,#nectar_fullscreen_rows:not(.afterLoaded) > div{height:calc(100vh - 85px);}.wpb_row.vc_row-o-full-height.top-level,.wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 85px);}html:not(.nectar-box-roll-loaded) .nectar-box-roll > #page-header-bg.fullscreen-header{top:86px;}.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded),.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded) .swiper-container{height:calc(100vh - 84px)!important;}.admin-bar .nectar-slider-wrap[data-fullscreen="true"]:not(.loaded),.admin-bar .nectar-slider-wrap[data-fullscreen="true"]:not(.loaded) .swiper-container{height:calc(100vh - 84px - 32px)!important;}}.admin-bar[class*="page-template-template-no-header"] .wpb_row.vc_row-o-full-height.top-level,.admin-bar[class*="page-template-template-no-header"] .wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 32px);}body[class*="page-template-template-no-header"] .wpb_row.vc_row-o-full-height.top-level,body[class*="page-template-template-no-header"] .wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:100vh;}@media only screen and (max-width:999px){.using-mobile-browser #nectar_fullscreen_rows:not(.afterLoaded):not([data-mobile-disable="on"]) > div{height:calc(100vh - 100px);}.using-mobile-browser .wpb_row.vc_row-o-full-height.top-level,.using-mobile-browser .wpb_row.vc_row-o-full-height.top-level > .col.span_12,[data-permanent-transparent="1"].using-mobile-browser .wpb_row.vc_row-o-full-height.top-level,[data-permanent-transparent="1"].using-mobile-browser .wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 100px);}html:not(.nectar-box-roll-loaded) .nectar-box-roll > #page-header-bg.fullscreen-header,.nectar_fullscreen_zoom_recent_projects,.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded),.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded) .swiper-container,#nectar_fullscreen_rows:not(.afterLoaded):not([data-mobile-disable="on"]) > div{height:calc(100vh - 47px);}.wpb_row.vc_row-o-full-height.top-level,.wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 47px);}body[data-transparent-header="false"] #ajax-content-wrap.no-scroll{min-height:calc(100vh - 47px);height:calc(100vh - 47px);}}.screen-reader-text,.nectar-skip-to-content:not(:focus){border:0;clip:rect(1px,1px,1px,1px);clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute!important;width:1px;word-wrap:normal!important;}.row .col img:not([srcset]){width:auto;}.row .col img.img-with-animation.nectar-lazy:not([srcset]){width:100%;}
/*side nav*/
#slide-out-widget-area.slide-out-from-right-hover {
    width: 200px !important;
    padding: 40px !important;
}

#slide-out-widget-area .secondary-header-text, body #slide-out-widget-area .inner-wrap .inner .nectar-header-text-content {
    background-color: transparent;
}

@media only screen and (max-width: 690px) {
    #slide-out-widget-area.slide-out-from-right-hover {
    width: 100vw !important;
    padding: 40px !important;
    font-family: "knockout51" !important;
}

body #slide-out-widget-area.slide-out-from-right-hover .inner .off-canvas-menu-container li a {
    font-family: "knockout74" !important;
    line-height: 0.9;
    font-size: 30px !important;
}
}

/*dropdown menu styling*/
.sf-menu li ul li a .menu-title-text:after {
    background-color: rgba(16,16,16,0.7) !important;
}

body:not([data-header-format="left-header"]) #header-outer .sf-menu li ul {
    background-color: rgba(16,16,15,0.7) !important;
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
    border-radius: 20px;
    border: 1px solid rgba(250,250,250,0.1);
}

.menu-title-text {
    font-size: 14px !important;
}


.sub-menu {
 margin-top: 0px;
 margin-left: -17px;
}

.sf-menu>li ul {
    width: 15em !important;
}

/*links*/
.span_12.light .wpb_text_column a, .span_12.light .wpb_text_column a:not(:hover)  {
    color: #75FE72;
    opacity: 1;
}

.span_12.light .wpb_text_column a:hover {
    color: #75FE72;
    filter: brightness(150%);
}


/*small rotating logo wall*/
.logo-wall .flickity-slider {
    opacity: 0.2;
}

.logo-wall .flickity-slider:hover {
    opacity: 1;
    transition: opacity 0.5s;
}

.logo-wall-number:hover ~ .logo-wall .flickity-slider {
    opacity: 1;
    transition: opacity 0.5s;
}

.logo-wall-container .nectar-flickity:not(.masonry) .flickity-slider .cell img {
    padding: 10px;
    display: block;
    max-width: 170px;
    max-height:95px;
    width: auto;
    height: auto;
    margin: auto;
}

.nectar-flickity:not(.masonry) .flickity-slider .cell img {
    padding: 10px;
    display: block;
    max-width: 170px;
    max-height:95px;
    width: auto;
    height: auto;
    margin: auto;
}

/*big logo wall*/

/*logo wall titles*/
.big-logo-wall .nectar-rotating-words-title .dynamic-words span {
    display: inline-block !important;
    white-space: nowrap !important;
}

/*speaker carousel*/
.speaker-name h5 {
    font-family: "knockout66";
    font-size: 75px !important;
    line-height: 0.8 !important;
}

.speaker-title h4 {
    font-size: 18px !important;
    line-height: 1 !important;
    color: #75FE72 !important;
}

.speaker-carousel .column-image-bg-wrap {
    filter: grayscale(1) contrast(120%);
}
.speaker-title h4 {
    font-size: 18px !important;
    line-height: 1 !important;
    color: #75FE72 !important;
}

.speaker-carousel .column-image-bg-wrap {
    filter: grayscale(1) contrast(120%);
}

.nectar-rotating-words-title .dynamic-words span {
    white-space: normal;
}

/*graphs*/
.apexcharts-title-text {
    font-family: "knockout74" !important;
    text-transform: uppercase;
    font-size: 20px;
}

.apexcharts-legend-text, .apexcharts-tooltip-text, 
.apexcharts-legend-marker, .apexcharts-legend-series {
    font-family: "knockout31" !important;
}

.apexcharts-series path {
    stroke: #101010 !important;
    stroke-width: 3;
}

@media only screen and (max-width: 600px) {
.apexcharts-series path {
    stroke: #101010 !important;
    stroke-width: 1 !important;
}
}

 .apexcharts-datalabels text {
     fill: #101010 !important;
     filter: none;
     font-family: "knockout31" !important;
 }
 
 .apexcharts-canvas text {
     font-family: "knockout31" !important;
 }
 
 .apexcharts-tooltip, .apexcharts-tooltip-title {
     background: rgba(0,0,0,0.6) !important;
     backdrop-filter: blur(10px);
     -webkit-backdrop-filter: blur(10px) !important;
     font-family: "knockout31" !important;
 }

/*newsletter subscribe*/
#mc_embed_signup_scroll h2 {
    line-height: 1 !important;
}

#mc_embed_signup_scroll p {
    padding-bottom: 0 !important;
}

#mc_embed_signup_scroll .mc-field-group p {
    margin-block-start: 0em !important;
    margin-block-end: 0em !important;
}

#mc_embed_signup_scroll .mc-field-group ul {
    margin-block-start: 0em !important;
    margin-block-end: 0em !important;
    margin-inline-start: 0px !important;
    margin-inline-end: 0px !important;
    padding-inline-start: 0px !important;
}

#mc_embed_signup_scroll .mc-field-group ul label {
    padding-right: 5px;
}

#mc_embed_signup_scroll .clear input {
    font-family: "Knockout31" !important;
    text-transform: uppercase;
    color: #101010 !Important;
}

#mc_embed_signup_scroll .mc-field-group, #mc_embed_signup_scroll .mc-field-group ul, #mce-responses .response  {
    padding-top: 10px;
}

#mce-responses .response {
    color: #75FE72 !important;
}

#mc_embed_signup_scroll {
    padding: 40px 40px 20px 40px !important;
}

/*FLIP BOXES*/

.flip-box-front, .flip-box-back {
    border: 1px solid #333333;
    border-radius: 50px;
    min-height: 475px;
}

.core .flip-box-front, .core .flip-box-back {
    min-height: 0px;
}

.nectar-flip-box .flip-box-back .inner, .nectar-flip-box .flip-box-front .inner {
    padding: 60px 50px 60px 50px !important;
}

.flip-box-front .inner h5 {
    font-size: 75px !important;
    line-height: 0.9 !important;
    text-align: center;
}

/*quotes*/
.nectar-rotating-words-title .dynamic-words span {
    white-space: normal;
}

.quote-titles .dynamic-words span {
    white-space: nowrap;
    text-transform: uppercase;
}

.quote-source {
    color: #75FE72;
}

/*speaker page*/
.project-title {
display:none;
}

.speaker-image {
    min-height: 60vh !important;
}

#full_width_portfolio ~ .nectar-social, .nectar-social .visible, .nectar-social .icon-default-style .steadysets-icon-share {
    display: none !important;
}

.speaker-image:hover .column-image-bg {
    filter: grayscale(0) !important;
    transition: filter 1s ease-in-out;
}

.speaker-page .column-image-bg {
    filter: grayscale(1) !important;
    transition: filter 1s ease-in-out;
}

.speaker-text {
    column-count: 2;
    column-gap: 20px;
}

.speaker-page .quick-facts {
    display: none;
}

@media only screen and (max-width: 1000px) {
 .speaker-page .column-image-bg  {
    /*background-attachment: fixed !important;
    background-size: 100vw auto !important;
    background-position: 0vw 50px !important;*/
  }
  
  .speaker-text {
    column-count: 1;
    column-gap: 0px;
}
}

.portfolio-filters-inline ul li a {
    text-transform: uppercase;
}

/*CORE AUDIENCE TEMPLATE*/
.core-audience-tagline {
    backdrop-filter: blur(5px) !Important;
    -webkit-backdrop-filter: blur(5px) !Important;
    border-radius: 20px;
    border: 1px solid #333;
    padding: 5%;
    background-color: rgba(250,250,250,0.1);
    /*box-shadow: inset 0 0 10px #fafafa;*/
}

.core-audience-tagline-wide {
    max-width: 50vw;
    margin: auto;
}

.core-audience-usp .toggle-title a {
    font-family: "knockout31" !important;
    font-size: 20px !important;
}

.core-audience-concepts .column-bg-layer {
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}


.inpage-nav .vc_column-inner {
    background-color: #101010 !important;
   /*backdrop-filter: blur(5px);*/
}

/*.inpage-nav .nav-items .vc_column-inner{
    backdrop-filter: blur(0px);
}*/

.inpage-nav .nav-items a {
    color: #fafafa !important;
    font-size: 16px;
}

.inpage-nav .nav-items a:hover {
    color: #75FE72 !important;
}

.inpage-nav .nav-items a:active {
    color: #75FE72 !important;
}

@media only screen and (max-width: 1000px) {
  .inpage-nav {
    display: none;
  }
}

.core-audience-concepts .navigation_func_active_link_only .scrolling-tab-nav .menu-item .sub-desc  {
    line-height: 1.3;
}

/*text with inline media*/
.nectar-text-inline-images__marker {
    clip-path: unset;
    margin: 10px;
}

/*NEWSROOM*/
.post-heading {
    line-height: 1.2 !important;
}

.nectar-post-grid .nectar-post-grid-item .content .post-heading {
    max-width: 100% !important;
}

.nectar-post-grid[data-border-radius="15px"][data-text-layout="all_bottom_left_shadow"] .nectar-post-grid-item:before, .nectar-post-grid[data-border-radius="15px"] .nectar-post-grid-item .inner, .nectar-post-grid[data-border-radius="15px"] .bg-overlay, [data-style="mouse_follow_image"] .nectar-post-grid[data-border-radius="15px"] .nectar-post-grid-item-bg-wrap-inner {
    border-radius: 50px;
}

.category-articles .wpb_text_column p a {
    color: #0075FF !important;
}

.category-articles .nectar-cta {
    color: #101010 !important;
}

/*NEWSROOM INDIVIDUAL ARTICLE*/
/*.page-header-bg-image {
    position: fixed !important;
}*/

.single-post.material .container-wrap {
    background-color: #fafafa;
}

.article blockquote {
    line-height: 1.1 !important;
    padding: 0% 10% 0% 10%;
}

.open-quote {
    line-height: 50px !important;
}

#author-info, #autohor-bio {
    display: none !important;
}

/*filter and locate map*/
.tooltip-wrap {
    padding: 15px;
    font-family: "Knockout31" !important;
}

.row .col p:last-child {
    padding: 0px;
}

.nice-tooltips .leaflet-popup-content p {
    font-size: 13px !Important;
}

.tooltip-address {
    padding-bottom: 5px;
}

.tooltip-thumb {
    padding: 10px 0px 10px 0px;
}

.mfp-title {
    font-size: 20px !important;
    line-height: 1.1 !important;
}

.meta-excerpt {
    font-size: 18px !important;
    line-height: 1.1;
}

/*search bar*/
.nectar-ajax-search-results .search-post-item h5 {
    font-family: "Knockout51" !important;
}

/*formidable*/

.frm_style_formidable-style.with_frm_style .frm_submit button {
    font-family: "Knockout51" !important;
    text-transform: uppercase;
}
</style>
<link rel='stylesheet' id='salient-child-style-css' href='https://slush.org/wp-content/themes/salient-child/style.css?ver=15.0.8' type='text/css' media='all' />
<script type='text/javascript' src='https://slush.org/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2' id='wp-polyfill-inert-js'></script>
<script type='text/javascript' src='https://slush.org/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.11' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://slush.org/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' src='https://slush.org/wp-includes/js/dist/hooks.min.js?ver=c6aec9a8d4e5a5d543a1' id='wp-hooks-js'></script>
<script type='text/javascript' id='say-what-js-js-extra'>
/* <![CDATA[ */
var say_what_data = {"replacements":{"salient-portfolio|Next Project|":"Next Speaker","salient-portfolio|Previous Project|":"Previous Speaker","salient-portfolio|Back to all projects|":"Back to all speakers"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://slush.org/wp-content/plugins/say-what/assets/build/frontend.js?ver=fd31684c45e4d85aeb4e' id='say-what-js-js'></script>
<script type='text/javascript' src='https://slush.org/wp-includes/js/jquery/jquery.min.js?ver=3.7.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://slush.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1' id='jquery-migrate-js'></script>

<!-- Google Analytics snippet added by Site Kit -->
<script type='text/javascript' src='https://www.googletagmanager.com/gtag/js?id=G-YPCWFFEH7W' id='google_gtagjs-js' async></script>
<script id="google_gtagjs-js-after" type="text/javascript">
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag('set', 'linker', {"domains":["slush.org"]} );
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "G-YPCWFFEH7W");
</script>

<!-- End Google Analytics snippet added by Site Kit -->
<link rel="https://api.w.org/" href="https://slush.org/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://slush.org/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.3.1" />
<meta name="cdp-version" content="1.4.2" /><meta name="generator" content="Site Kit by Google 1.114.0" /><script>
    (function(c,u,s,t,o,b,a,r) {var e;c[o]=[];c[b]=a;e=u.createElement(s);
        r=u.getElementsByTagName(s)[0];e.async=1;e.src=t;
        r.parentNode.insertBefore(e,r);})(window,document,'script',
        'https://api.custobar.com/js/v1/custobar.js',
        'cstbr','cstbrConfig',{"_companyToken":"APINONEKW6YSHPQ4BQWPZNC5FH5Z6CMRT3TWLM3A"});

    cstbrConfig.productId = YOUR_PRODUCT_ID;
    cstbrConfig.customerId = YOUR_CUSTOMER_ID;
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('mailing-list-form');

  form.addEventListener('submit', function(e) {
    e.preventDefault();

    const data = {};
    const fields = form.elements;

    for (let i = 0, f = fields[0]; i < fields.length; i += 1, f = fields[i]) {
      if (f.name) {
        data[f.name] = f.value;
      }
    }

    window.cstbr.push(data);

form.style.display = 'none';

document.getElementById('mailing-list-feedback').style.display = 'block';

  });
});
</script><script type="text/javascript"> var root = document.getElementsByTagName( "html" )[0]; root.setAttribute( "class", "js" ); </script><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>

<!-- Google Tag Manager snippet added by Site Kit -->
<script type="text/javascript">
			( function( w, d, s, l, i ) {
				w[l] = w[l] || [];
				w[l].push( {'gtm.start': new Date().getTime(), event: 'gtm.js'} );
				var f = d.getElementsByTagName( s )[0],
					j = d.createElement( s ), dl = l != 'dataLayer' ? '&l=' + l : '';
				j.async = true;
				j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
				f.parentNode.insertBefore( j, f );
			} )( window, document, 'script', 'dataLayer', 'GTM-52FNNPH' );
			
</script>

<!-- End Google Tag Manager snippet added by Site Kit -->
<link rel="icon" href="https://slush.org/wp-content/uploads/2023/05/slush-s-icon-100x100.jpeg" sizes="32x32" />
<link rel="icon" href="https://slush.org/wp-content/uploads/2023/05/slush-s-icon.jpeg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://slush.org/wp-content/uploads/2023/05/slush-s-icon.jpeg" />
<meta name="msapplication-TileImage" content="https://slush.org/wp-content/uploads/2023/05/slush-s-icon.jpeg" />
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head><body class="error404 material wpb-js-composer js-comp-ver-6.9.1 vc_responsive" data-footer-reveal="1" data-footer-reveal-shadow="none" data-header-format="default" data-body-border="off" data-boxed-style="" data-header-breakpoint="1000" data-dropdown-style="minimal" data-cae="easeOutCubic" data-cad="750" data-megamenu-width="contained" data-aie="none" data-ls="magnific" data-apte="standard" data-hhun="0" data-fancy-form-rcs="default" data-form-style="default" data-form-submit="regular" data-is="minimal" data-button-style="slightly_rounded" data-user-account-button="false" data-flex-cols="true" data-col-gap="default" data-header-inherit-rc="false" data-header-search="true" data-animated-anchors="true" data-ajax-transitions="true" data-full-width-header="true" data-slide-out-widget-area="true" data-slide-out-widget-area-style="slide-out-from-right-hover" data-user-set-ocm="1" data-loading-animation="none" data-bg-header="false" data-responsive="1" data-ext-responsive="true" data-ext-padding="90" data-header-resize="1" data-header-color="custom" data-cart="false" data-remove-m-parallax="" data-remove-m-video-bgs="" data-m-animate="1" data-force-header-trans-color="light" data-smooth-scrolling="0" data-permanent-transparent="false" >
	
	<script type="text/javascript">
	 (function(window, document) {

		 if(navigator.userAgent.match(/(Android|iPod|iPhone|iPad|BlackBerry|IEMobile|Opera Mini)/)) {
			 document.body.className += " using-mobile-browser mobile ";
		 }

		 if( !("ontouchstart" in window) ) {

			 var body = document.querySelector("body");
			 var winW = window.innerWidth;
			 var bodyW = body.clientWidth;

			 if (winW > bodyW + 4) {
				 body.setAttribute("style", "--scroll-bar-w: " + (winW - bodyW - 4) + "px");
			 } else {
				 body.setAttribute("style", "--scroll-bar-w: 0px");
			 }
		 }

	 })(window, document);
   </script>		<!-- Google Tag Manager (noscript) snippet added by Site Kit -->
		<noscript>
			<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-52FNNPH" height="0" width="0" style="display:none;visibility:hidden"></iframe>
		</noscript>
		<!-- End Google Tag Manager (noscript) snippet added by Site Kit -->
		<a href="#ajax-content-wrap" class="nectar-skip-to-content">Skip to main content</a><div class="ocm-effect-wrap"><div class="ocm-effect-wrap-inner"><div id="ajax-loading-screen" data-disable-mobile="1" data-disable-fade-on-click="1" data-effect="standard" data-method="standard"><div class="loading-icon none"><div class="material-icon">
						<svg class="nectar-material-spinner" width="60px" height="60px" viewBox="0 0 60 60">
							<circle stroke-linecap="round" cx="30" cy="30" r="26" fill="none" stroke-width="6"></circle>
				  		</svg>	 
					</div></div></div>	
	<div id="header-space"  data-header-mobile-fixed='1'></div> 
	
		<div id="header-outer" data-has-menu="true" data-has-buttons="yes" data-header-button_style="default" data-using-pr-menu="false" data-mobile-fixed="1" data-ptnm="false" data-lhe="default" data-user-set-bg="#101010" data-format="default" data-permanent-transparent="false" data-megamenu-rt="0" data-remove-fixed="0" data-header-resize="1" data-cart="false" data-transparency-option="" data-box-shadow="large" data-shrink-num="6" data-using-secondary="0" data-using-logo="1" data-logo-height="30" data-m-logo-height="24" data-padding="28" data-full-width="true" data-condense="false" >
		
<div id="search-outer" class="nectar">
	<div id="search">
		<div class="container">
			 <div id="search-box">
				 <div class="inner-wrap">
					 <div class="col span_12">
						  <form role="search" action="https://slush.org/" method="GET">
														 <input type="text" name="s" id="s" value="" aria-label="Search" placeholder="Search" />
							 
						<span>Hit enter to search or ESC to close</span>
												</form>
					</div><!--/span_12-->
				</div><!--/inner-wrap-->
			 </div><!--/search-box-->
			 <div id="close"><a href="#"><span class="screen-reader-text">Close Search</span>
				<span class="close-wrap"> <span class="close-line close-line1"></span> <span class="close-line close-line2"></span> </span>				 </a></div>
		 </div><!--/container-->
	</div><!--/search-->
</div><!--/search-outer-->

<header id="top">
	<div class="container">
		<div class="row">
			<div class="col span_3">
				<ul class="left-aligned-ocm" data-user-set="1"><li class="slide-out-widget-area-toggle" data-icon-animation="simple-transform" data-custom-color="false"><div> <a href="#sidewidgetarea" aria-label="Navigation Menu" aria-expanded="false" class="closed"> <span class="screen-reader-text">Menu</span><span aria-hidden="true"> <i class="lines-button x2"> <i class="lines"></i> </i> </span> </a> </div></li></ul>				<a id="logo" href="https://slush.org" data-supplied-ml-starting-dark="false" data-supplied-ml-starting="false" data-supplied-ml="false" >
					<img class="stnd skip-lazy" width="5028" height="608" alt="Slush 2023" src="https://slush.org/wp-content/uploads/2023/05/LOGO-date-location.png"  />				</a>
							</div><!--/span_3-->

			<div class="col span_9 col_last">
									<div class="nectar-mobile-only mobile-header"><div class="inner"></div></div>
									<a class="mobile-search" href="#searchbox"><span class="nectar-icon icon-salient-search" aria-hidden="true"></span><span class="screen-reader-text">search</span></a>
														<div class="slide-out-widget-area-toggle mobile-icon slide-out-from-right-hover" data-custom-color="false" data-icon-animation="simple-transform">
						<div> <a href="#sidewidgetarea" aria-label="Navigation Menu" aria-expanded="false" class="closed">
							<span class="screen-reader-text">Menu</span><span aria-hidden="true"> <i class="lines-button x2"> <i class="lines"></i> </i> </span>
						</a></div>
					</div>
				
									<nav>
													<ul class="sf-menu">
								<li id="menu-item-1848" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children nectar-regular-menu-item sf-with-ul menu-item-1848"><a><span class="menu-title-text">FOR VISITORS</span><span class="sf-sub-indicator"><i class="fa fa-angle-down icon-in-menu" aria-hidden="true"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-22" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-22"><a href="https://slush.org/startups"><span class="menu-title-text">STARTUPS</span></a></li>
	<li id="menu-item-23" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-23"><a href="https://slush.org/investors"><span class="menu-title-text">INVESTORS</span></a></li>
	<li id="menu-item-4116" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-4116"><a href="https://slush.org/attendees/"><span class="menu-title-text">ATTENDEES</span></a></li>
	<li id="menu-item-24" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-24"><a href="https://slush.org/media"><span class="menu-title-text">MEDIA</span></a></li>
	<li id="menu-item-1164" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-1164"><a href="https://slush.org/lps"><span class="menu-title-text">LIMITED PARTNERS</span></a></li>
	<li id="menu-item-1398" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-1398"><a href="https://slush.org/volunteers"><span class="menu-title-text">VOLUNTEERS</span></a></li>
	<li id="menu-item-3257" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-3257"><a href="https://slush.org/partners"><span class="menu-title-text">PARTNERS</span></a></li>
</ul>
</li>
<li id="menu-item-6345" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children nectar-regular-menu-item sf-with-ul menu-item-6345"><a href="https://platform.slush.org/public/slush23/stage-programs"><span class="menu-title-text">PROGRAM</span><span class="sf-sub-indicator"><i class="fa fa-angle-down icon-in-menu" aria-hidden="true"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-6346" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-6346"><a href="https://platform.slush.org/public/slush23/stage-programs"><span class="menu-title-text">STAGE AGENDA</span></a></li>
	<li id="menu-item-7499" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-7499"><a href="https://slush.org/startups/founders-day/"><span class="menu-title-text">FOUNDERS DAY</span></a></li>
	<li id="menu-item-7500" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-7500"><a href="https://slush.org/investor-day/"><span class="menu-title-text">INVESTOR DAY</span></a></li>
	<li id="menu-item-7502" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-7502"><a href="https://slush.org/media/#slush-week"><span class="menu-title-text">MEDIA DAY</span></a></li>
	<li id="menu-item-4770" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-4770"><a href="http://www.slush.org/slush-official-side-events"><span class="menu-title-text">SLUSH OFFICIAL SIDE EVENTS</span></a></li>
	<li id="menu-item-4771" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-4771"><a href="https://platform.slush.org/public/slush23/side-events"><span class="menu-title-text">ALL SIDE EVENTS</span></a></li>
	<li id="menu-item-6574" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-6574"><a href="https://slush.org/afterparty/"><span class="menu-title-text">AFTERPARTY</span></a></li>
	<li id="menu-item-1760" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-1760"><a href="https://slush.org/speakers/"><span class="menu-title-text">SPEAKERS</span></a></li>
</ul>
</li>
<li id="menu-item-3250" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children nectar-regular-menu-item sf-with-ul menu-item-3250"><a href="https://slush.org/event-info"><span class="menu-title-text">INFO</span><span class="sf-sub-indicator"><i class="fa fa-angle-down icon-in-menu" aria-hidden="true"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-6043" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-6043"><a href="https://slush.org/event-info/"><span class="menu-title-text">EVENT INFO</span></a></li>
	<li id="menu-item-7498" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-7498"><a href="https://slush.org/meetings-at-slush/"><span class="menu-title-text">BOOKING MEETINGS</span></a></li>
	<li id="menu-item-3251" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-3251"><a href="https://slush.org/guide-to-helsinki/"><span class="menu-title-text">GUIDE TO HELSINKI</span></a></li>
	<li id="menu-item-6234" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-6234"><a href="https://slush.org/slushtainability/"><span class="menu-title-text">SLUSHTAINABILITY</span></a></li>
	<li id="menu-item-3020" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-3020"><a href="https://slush.org/faq/"><span class="menu-title-text">FAQ</span></a></li>
</ul>
</li>
<li id="menu-item-2228" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-2228"><a href="https://slush.org/slush-100/"><span class="menu-title-text">SLUSH 100</span></a></li>
<li id="menu-item-6166" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-6166"><a href="https://platform.slush.org/slush23/matchmaking/browse"><span class="menu-title-text">MATCHMAKING</span></a></li>
<li id="menu-item-7713" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-7713"><a href="https://slush.org/livestream/"><span class="menu-title-text">LIVESTREAM</span></a></li>
<li id="menu-item-2510" class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-2510"><a href="https://platform.slush.org/"><span class="menu-title-text">LOGIN</span></a></li>
							</ul>
													<ul class="buttons sf-menu" data-user-set-ocm="1">

								<li id="search-btn"><div><a href="#searchbox"><span class="icon-salient-search" aria-hidden="true"></span><span class="screen-reader-text">search</span></a></div> </li>
							</ul>
						
					</nav>

					
				</div><!--/span_9-->

				
			</div><!--/row-->
					</div><!--/container-->
	</header>		
	</div>
		<div id="ajax-content-wrap">

<div class="container-wrap">
	
		
	<div class="container main-content">
		
		<div class="row">
			
			<div class="col span_12">
				
				<div id="error-404" 
								 >
					<h1>404</h1>
					<h2>Page Not Found</h2>
					
											   <a class="nectar-button large regular-button accent-color has-icon" data-color-override="false" data-hover-color-override="false" href="https://slush.org"><span>Back Home </span><i class="icon-button-arrow"></i></a>
										</div>
				
			</div><!--/span_12-->
			
		</div><!--/row-->
		
	</div><!--/container-->
	</div><!--/container-wrap-->

<div id="footer-outer" data-cols="1" data-custom-color="true" data-disable-copyright="true" data-matching-section-color="false" data-copyright-line="false" data-using-bg-img="false" data-bg-img-overlay="0.8" data-full-width="1" data-using-widget-area="true" data-link-hover="default">
	
		
	<div id="footer-widgets" data-has-widgets="false" data-cols="1">
		
		<div class="container">
			
						
			<div class="row">
				
								
				<div class="col span_12">
												<div class="widget">			
							</div>
											</div>
					
											
						
													
															
							</div>
													</div><!--/container-->
					</div><!--/footer-widgets-->
					
						
</div><!--/footer-outer-->


	<div id="slide-out-widget-area-bg" class="slide-out-from-right-hover dark">
				</div>

		<div id="slide-out-widget-area" class="slide-out-from-right-hover" data-dropdown-func="separate-dropdown-parent-link" data-back-txt="Back">

			<div class="inner-wrap">
			<div class="inner" data-prepend-menu-mobile="true">

				<a class="slide_out_area_close" href="#"><span class="screen-reader-text">Close Menu</span>
					<span class="close-wrap"> <span class="close-line close-line1"></span> <span class="close-line close-line2"></span> </span>				</a>


									<div class="off-canvas-menu-container mobile-only" role="navigation">

						
						<ul class="menu">
							<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1848"><a>FOR VISITORS</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22"><a href="https://slush.org/startups">STARTUPS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23"><a href="https://slush.org/investors">INVESTORS</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4116"><a href="https://slush.org/attendees/">ATTENDEES</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24"><a href="https://slush.org/media">MEDIA</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1164"><a href="https://slush.org/lps">LIMITED PARTNERS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1398"><a href="https://slush.org/volunteers">VOLUNTEERS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3257"><a href="https://slush.org/partners">PARTNERS</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-6345"><a href="https://platform.slush.org/public/slush23/stage-programs">PROGRAM</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-6346"><a href="https://platform.slush.org/public/slush23/stage-programs">STAGE AGENDA</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7499"><a href="https://slush.org/startups/founders-day/">FOUNDERS DAY</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7500"><a href="https://slush.org/investor-day/">INVESTOR DAY</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7502"><a href="https://slush.org/media/#slush-week">MEDIA DAY</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4770"><a href="http://www.slush.org/slush-official-side-events">SLUSH OFFICIAL SIDE EVENTS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4771"><a href="https://platform.slush.org/public/slush23/side-events">ALL SIDE EVENTS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-6574"><a href="https://slush.org/afterparty/">AFTERPARTY</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1760"><a href="https://slush.org/speakers/">SPEAKERS</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-3250"><a href="https://slush.org/event-info">INFO</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6043"><a href="https://slush.org/event-info/">EVENT INFO</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7498"><a href="https://slush.org/meetings-at-slush/">BOOKING MEETINGS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3251"><a href="https://slush.org/guide-to-helsinki/">GUIDE TO HELSINKI</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6234"><a href="https://slush.org/slushtainability/">SLUSHTAINABILITY</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3020"><a href="https://slush.org/faq/">FAQ</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2228"><a href="https://slush.org/slush-100/">SLUSH 100</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-6166"><a href="https://platform.slush.org/slush23/matchmaking/browse">MATCHMAKING</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7713"><a href="https://slush.org/livestream/">LIVESTREAM</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2510"><a href="https://platform.slush.org/">LOGIN</a></li>

						</ul>

						<ul class="menu secondary-header-items">
													</ul>
					</div>
										<div class="off-canvas-menu-container" role="navigation">
						<ul class="menu">
							<li id="menu-item-898" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-898"><a href="https://www.slush.org/slushd/">SLUSH&#8217;D</a></li>
<li id="menu-item-1165" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1165"><a href="https://node.slush.org/">NODE</a></li>
<li id="menu-item-1166" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1166"><a href="https://slush.org/newsroom/">NEWS</a></li>
<li id="menu-item-3850" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3850"><a href="https://slush.org/about/">ABOUT</a></li>
<li id="menu-item-6199" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6199"><a href="https://slush.org/helsinki-exposed/">SLUSH X HELSINKI</a></li>

						</ul>
					</div>

					
				</div>

				<div class="bottom-meta-wrap"><ul class="off-canvas-social-links"><li><a target="_blank" rel="noopener" href="https://twitter.com/SlushHQ"><i class="fa fa-twitter"></i></a></li><li><a target="_blank" rel="noopener" href="https://www.linkedin.com/company/slush/"><i class="fa fa-linkedin"></i></a></li><li><a target="_blank" rel="noopener" href="https://www.youtube.com/c/slush"><i class="fa fa-youtube-play"></i></a></li><li><a target="_blank" rel="noopener" href="https://www.instagram.com/SlushHQ/"><i class="fa fa-instagram"></i></a></li></ul></div><!--/bottom-meta-wrap--></div> <!--/inner-wrap-->
				</div>
		
</div> <!--/ajax-content-wrap-->

	<a id="to-top" href="#" class="
		"><i class="fa fa-angle-up"></i></a>
	</div></div><!--/ocm-effect-wrap--><link data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize data-noptimize rel='stylesheet' id='main-styles-non-critical-css' href='https://slush.org/wp-content/themes/salient/css/build/style-non-critical.css?ver=15.0.8' type='text/css' media='all' />
<link data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize data-noptimize rel='stylesheet' id='magnific-css' href='https://slush.org/wp-content/themes/salient/css/build/plugins/magnific.css?ver=8.6.0' type='text/css' media='all' />
<link data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize data-noptimize rel='stylesheet' id='nectar-ocm-core-css' href='https://slush.org/wp-content/themes/salient/css/build/off-canvas/core.css?ver=15.0.8' type='text/css' media='all' />
<link data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize data-noptimize rel='stylesheet' id='nectar-ocm-slide-out-right-hover-css' href='https://slush.org/wp-content/themes/salient/css/build/off-canvas/slide-out-right-hover.css?ver=15.0.8' type='text/css' media='all' />
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/jquery.easing.min.js?ver=1.3' id='jquery-easing-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/jquery.mousewheel.min.js?ver=3.1.13' id='jquery-mousewheel-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/priority.js?ver=15.0.8' id='nectar_priority-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/intersection-observer.min.js?ver=2.6.2' id='intersection-observer-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/transit.min.js?ver=0.9.9' id='nectar-transit-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/waypoints.js?ver=4.0.2' id='nectar-waypoints-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/plugins/salient-portfolio/js/third-party/imagesLoaded.min.js?ver=4.1.4' id='imagesLoaded-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/hoverintent.min.js?ver=1.9' id='hoverintent-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/magnific.js?ver=7.0.1' id='magnific-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/anime.min.js?ver=4.5.1' id='anime-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/third-party/superfish.js?ver=1.5.8' id='superfish-js'></script>
<script type='text/javascript' id='nectar-frontend-js-extra'>
/* <![CDATA[ */
var nectarLove = {"ajaxurl":"https:\/\/slush.org\/wp-admin\/admin-ajax.php","postID":"7949","rooturl":"https:\/\/slush.org","disqusComments":"false","loveNonce":"448b0231a4","mapApiKey":""};
var nectarOptions = {"delay_js":"0","quick_search":"true","react_compat":"disabled","header_entrance":"false","mobile_header_format":"default","ocm_btn_position":"left","left_header_dropdown_func":"default","ajax_add_to_cart":"0","ocm_remove_ext_menu_items":"remove_images","woo_product_filter_toggle":"0","woo_sidebar_toggles":"true","woo_sticky_sidebar":"0","woo_minimal_product_hover":"default","woo_minimal_product_effect":"default","woo_related_upsell_carousel":"false","woo_product_variable_select":"default"};
var nectar_front_i18n = {"next":"Next","previous":"Previous"};
/* ]]> */
</script>
<script type='text/javascript' src='https://slush.org/wp-content/themes/salient/js/build/init.js?ver=15.0.8' id='nectar-frontend-js'></script>
<script type='text/javascript' src='https://slush.org/wp-content/plugins/salient-core/js/third-party/touchswipe.min.js?ver=1.0' id='touchswipe-js'></script>
</body>
</html>
<!-- Page generated by LiteSpeed Cache 5.3.3 on 2023-11-29 04:13:44 -->